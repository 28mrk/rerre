from tkinter import *
root=Tk()
root.geometry("1366x768+0+0")

root.mainloop()