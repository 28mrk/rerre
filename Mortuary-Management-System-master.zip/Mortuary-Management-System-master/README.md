# Mortuary-Management-System
Egerton University Mortuary Management System Version 1.0.
Customized for Egerton University, Njoro-Kenya.
Run the Project.py to get an overview of the poted system.
The system is not completed in part to mysql authentication and some yet-to be completed pages.


Version 1.1 updated to include a database module and free options to include flexible pricing of services via the BodyRegistration v1.1 .py
Updated files on mysql login to handle the login details and encryption

Project1.py updated file to handle storing records in the databse and viewing records in the database as well as billing the body and displaying a receipt.

Receipt added and a print option which is working in the document canvas.py

